package GUI;

public class CheckoutGUI {
	//JFrame checkoutFrame;
	//JPanel checkoutPanel;
	//JButton 
}
