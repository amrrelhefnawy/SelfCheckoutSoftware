package org.lsmr.selfcheckout.software;

@SuppressWarnings("serial")
public class AttendantBlockException extends Exception {
	public AttendantBlockException(String message) {
		super(message);
	}
}
