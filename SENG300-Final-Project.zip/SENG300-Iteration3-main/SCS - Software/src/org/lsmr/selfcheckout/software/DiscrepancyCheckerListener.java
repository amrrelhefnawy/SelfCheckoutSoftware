package org.lsmr.selfcheckout.software;

public interface DiscrepancyCheckerListener {
    void notifyDiscrepancy();
}
