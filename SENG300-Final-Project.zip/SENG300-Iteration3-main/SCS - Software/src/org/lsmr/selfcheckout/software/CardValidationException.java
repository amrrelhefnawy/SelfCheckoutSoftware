package org.lsmr.selfcheckout.software;

public class CardValidationException extends Exception {
	public CardValidationException(String message) {
		super(message);
	}
}
