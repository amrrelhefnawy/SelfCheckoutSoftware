package org.lsmr.selfcheckout.software.test;

import org.junit.Test;

public class SelfCheckoutStationSoftwareTest {

	@Test
	public void testCheckout() {

	}

}
